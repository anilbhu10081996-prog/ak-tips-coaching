# A.K Tips Coaching — Server Starter

यह production architecture का starter है: Node.js + Express + PostgreSQL + Prisma + JWT + bcrypt + Helmet.

## Run
1. Node.js LTS और PostgreSQL install करें.
2. `npm install`
3. `.env.example` को `.env` बनाकर DATABASE_URL और JWT_SECRET भरें.
4. `npx prisma generate`
5. `npx prisma migrate dev --name init`
6. कुछ batches database में डालें.
7. `npm start`
8. Browser: `http://localhost:3000`

## Security
- Password database में hash होकर जाता है.
- JWT server-authentication के लिए है.
- Paid access database enrollment से नियंत्रित होगा.
- PhonePe secret frontend में नहीं जाएगा.

## PhonePe
PhonePe का live integration जानबूझकर placeholder रखा गया है क्योंकि credentials/API contract को current official PhonePe documentation के अनुसार server पर configure करना चाहिए. Payment success को केवल client-side button से mark नहीं करना चाहिए. Production में provider callback/status verification के बाद ही Enrollment बनाएं.
